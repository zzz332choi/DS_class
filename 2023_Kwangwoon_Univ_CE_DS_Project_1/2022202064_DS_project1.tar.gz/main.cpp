#define CRT_SECURE_NO_WARNINGS
#include "Manager.h"

int main() {
	Manager manager;
	manager.run("command.txt");

	return 0;
}
